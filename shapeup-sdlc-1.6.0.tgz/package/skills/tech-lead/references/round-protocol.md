# Round Protocol

The orchestration loop in detail. A "round" is one BUILD phase followed by exactly one
EVAL phase. The feature is done when an EVAL round returns PASS.

> `tasks/_index.md` referenced throughout this file lives in the LOCAL gitignored root
> (`.shapeup/<slug>/tasks/`, v3.2), not the
> SHARED spec dir. See tech-lead SKILL.md GATE L1b for the bootstrap step that regenerates it
> when missing.

```
round r = 1
loop:
    BUILD(r)                          # see r=1 vs r>1 below
    assert board 100% done            # GATE L2 — advisory: the hook warns, you decide
    verdict, bugs = EVAL(r)           # ONE spec-evaluator --feature pass
    if verdict == PASS:
        SHIP; break
    if r >= max_rounds:
        ESCALATE(bugs); break         # honest stop — no infinite loop
    r = r + 1                         # next round builds bugs only
```

## BUILD(r) semantics

| | r = 1 (initial build) | r > 1 (fix build) |
|--|----------------------|-------------------|
| Input | the whole task board | the bug list from EVAL(r-1) |
| Scope | every ready task, dependency/layer order, until board all ✅ | only the tasks/areas named by bugs |
| Command | compile-order `--next` → task-executor `--order` → ingest, looped | compile-order `--task <id> --operation fix` → dispatch → ingest, per bug |
| Passing areas | n/a | never touched |
| SPIKEs | resolved first (they block) | only if a bug is a SPIKE finding |

Re-opening tasks in r>1: the fix order's WorkResult reports the task `partial` while failing
and `done` when re-verified; ingest-result flips the board accordingly. The board reflects the
churn so the next EVAL sees a green board again.

Discovered Tasks:
If WorkResults carry `discoveries[]` during BUILD, ingest-result appends them to the discovery
ledger (`.shapeup/<slug>/discovery/ledger.md`) and the build loop pauses after the current
tasks are done. Compile + dispatch a reconcile order (ba-pitch-analyzer, operation: reconcile).
This reconciles them into new tasks and invariants and updates the board; the tech lead bumps
`discovered_rounds` in harness-run.md, then routes back to GATE L1b (Board Review) for PO
approval of the new tasks and estimates before resuming the BUILD loop.

## The EVAL timing rule (the core constraint)

EVAL fires **once** per round and **only** when GATE L2 has confirmed the board is 100% done.
It is never:
- called per task,
- called inside the BUILD loop,
- called on a partial board.

## Regression rule (r > 1) — QA-meeting Bước 1c

A fix round changes code; a fix can break what passed. Therefore EVAL(r>1) scope is **not**
just the fixed bugs:

```
EVAL(r) for r > 1:
  touched_UCs = every UC referenced (use_case_refs) by a task re-opened in BUILD(r)
  scope = fixed bugs' criteria
        + FULL re-run of `## Test Surface` rows for every touched UC
          (test-surface-conformance dimension, when active)
        + completeness re-check (cheap, static)
  untouched UCs' surfaces: NOT re-run (their code didn't change; re-probing everything
  every round would turn cheap end-of-round QA into a full-suite tax)
```

Pre-v2.9 specs (no Test Surface anywhere): the rule degrades to bug-criteria-only, as
before — and the verdict report notes `regression coverage: none (no test surface)`.
Honest reporting over silent coverage claims.

## QA edge hunt (post-PASS, pre-ship)

When EVAL(r) returns PASS for the **first** time in a run, the orchestrator delegates one
`/qa-edge-hunter` pass before SHIP (skippable via `--no-qa`, same spirit as `--no-eval`).
QA is a pure worker: no verdict, no score, no gate — it writes `~` findings to
`discovery/ledger.md` and a `qa/hunt-report.md`. Triage happens at SHIP/GATE L4:
- all findings stay `~` → SHIP; findings carry over as raw ideas (debt-free).
- PO/TL promote any to must-have → a fix round r+1 (those items only) → EVAL
  `--single-pass` on them → `/qa-edge-hunter --recheck` (re-probe ONLY the promoted items;
  never a second full hunt) → back to L4.
- Circuit breaker applies: out of rounds/appetite → ship with `~` findings recorded.
QA never runs on a FAIL round — a build that hasn't passed conformance isn't worth
edge-hunting yet.

Rationale (from the long-running harness work): a single end-of-round QA pass over the
running feature is cheap relative to the build (minutes vs hours) and catches the
last-mile defects, whereas grading every task multiplies evaluator cost for little gain
once the generator is competent. If the build round didn't finish, there is nothing
coherent to evaluate yet.

## Stop conditions
1. **PASS** — EVAL(r) verdict is PASS → SHIP.
2. **max_rounds (OUTER breaker)** — r would exceed `--max-rounds` (default 3) without PASS →
   ESCALATE: print the residual bug list, the rounds used, and hand the decision to the PO
   (scope contracts present: also `/scope-hammer --breaker outer`). Do not start another
   build round automatically.
3. **attempt_budget (INNER breaker, scope contracts only)** — a single scope's T0 attempt
   loop exhausts `--attempts` (default 5) without a green result → does NOT stop the round;
   queues a hammer PROPOSAL for GATE H and moves to the next scope in sequence. See
   "Three-level circuit breaker" below.
4. **wall_clock_budget (DEADLINE breaker, opt-in)** — elapsed seconds since the run receipt
   exceed `--wall-clock-budget` → do NOT start another build round or another scope; go
   straight to GATE H (`/scope-hammer --breaker deadline`). Checked with
   `scripts/budget-check.mjs` at every round boundary and enforced by `hooks/gate-deadline.mjs`,
   which denies a `task-executor` dispatch past the deadline while leaving `spec-evaluator`,
   `scope-hammer`, `qa-edge-hunter` and `advisor-protocol` reachable — a run past its deadline
   must still be able to judge, hammer, and close. Off unless configured.
5. **Hard error** — a sub-skill fails irrecoverably (e.g. spec folder gone, app won't
   build at all) → stop and report; do not retry blindly.
6. **User halt** — at any L-gate the user can stop the run; the ledger preserves state for
   `--from` resume.

## Three-level circuit breaker

```
OUTER    round_budget (max_rounds)  — the six-week-timebox analog. Decremented once per
                                       round at GATE L2, regardless of how many scopes it
                                       covered. Hitting 0 → GATE H immediately (§ above).
INNER    attempt_budget (per scope) — decremented once per T0 attempt inside BUILD round r.
                                       Hitting its cap WITHOUT a T0-green result trips the
                                       inner breaker for that scope only: the scope is queued
                                       as a hammer PROPOSAL (not a hard stop) and the round
                                       moves on to the next scope in the L1b sequence.
DEADLINE wall_clock_budget_s        — elapsed seconds since the run receipt. Opt-in; off
                                       unless set at L0. Tripping routes to GATE H with
                                       --breaker deadline. Enforced by hooks/gate-deadline.mjs.
```

**Why the third one exists — it was measured, and it corrected an earlier diagnosis.** On the
SDD harness benchmark (F3, Sonnet 5) this harness was killed at the declared 1800 s cap and
published as a DNF. The natural reading was that it had stalled at a gate. Re-reading the
retained transcript says otherwise: **327 turns, 262 tool calls, 37 file writes, 19 gate markers,
last gate L3, and zero stall signals** — the least talkative shapeup run in the whole matrix. It
was working when the clock ran out.

Both existing breakers count *events*, not time: `round_budget` moves once per round,
`attempt_budget` once per T0 attempt. Neither can observe that round 1 has been running for
twenty-nine minutes, so a run can burn its entire wall clock with both breakers untouched. The
cost is not the DNF row — it is that a run killed from *outside* ships nothing, not even the
scopes that were already green. A breaker that trips from the inside routes to GATE H, where
scope-hammer compares the shippable subset against the baseline and ships what works. Same clock,
different ending.
Nesting rationale (DD-9): a struggling scope should not freeze every other scope's progress
in the same round — only running out of *rounds* (the real six-week analog) stops the whole
run. A scope that trips its inner breaker still gets judged fairly at GATE H: scope-hammer
compares "ship without this scope" against the baseline, same as any other cut candidate — it
is never silently dropped, and it is never allowed to block scopes that ARE working.

## Isolated attempt loop — one T0 attempt, in detail (scope contracts only)

```
compile-order --scope … --round N --attempt M
                                   → zero-memory WorkOrder (scope contract + this scope's
                                      tasks + digested errors + ledger decisions — compiled
                                      facts, no chat history by construction)
dispatch task-executor --order …   → code within substrate; WorkResult in results/
ingest-result <result>             → board/ledger writes; escalates[] queued
handle_escalations(≤3/scope/round) → /advisor-protocol; answer promoted to round-ledger.md
                                      immediately (must survive the NEXT attempt's fresh
                                      context — this is what "zero-memory" is compatible with
                                      escalation memory means, DD-8)
t0-verify.mjs                      → fixtures + DB probe + (on green) seesaw
  green            → attempt loop breaks; scope reaches DOWNHILL_EXECUTION
  red, regression  → git stash (never a hard discard) + retry; a FINISHED scope's fixture
                      broke (PA5) — the whole point of running seesaw before declaring green
  red, own fixture  → AEGIS-digest the failure into {file, line, core_message} triples,
                      feed them into the NEXT attempt's brief; loop
```
This replaces the old flat per-task loop for any scope that has a contract;
scopes/specs without one keep the v0.2.6 behavior verbatim (see BUILD(r) table above).

## --no-eval (skip evaluation)
A tech-lead judgment, surfaced at GATE L2: if the feature is clearly within what the model
builds reliably solo, the evaluator is optional overhead. With `--no-eval`, after GATE L2
the run goes straight to SHIP with verdict `not-evaluated` recorded in the ledger and a
clear note that nothing was verified beyond the build's own task-executor GATE D checks.

## Round-cost intuition
Build dominates; eval is cheap. Expect each EVAL round to cost a small fraction of a BUILD
round. This is why running eval once per round (not per task) is the right trade: you pay a
little QA at the end of each build and keep the expensive build coherent in between.
