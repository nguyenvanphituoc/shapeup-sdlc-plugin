---
type: pitch
feature: FEATURE_SLUG
appetite: "X weeks"
status: draft
bounded_context: CONTEXT
entities: []
tags: []
skill_version: "2.5"
audit_rules_version: "2.5"
---

# Pitch: FEATURE TITLE

## Problem
<!-- 2-3 sentences: what user pain or opportunity drives this feature -->

## Appetite
**X weeks** — if scope grows beyond this, cut features, do not extend timeline.

## Boundaries

### In Scope
- ...

### Non-Go
- ...

## Solution Elements

### Breadboarding
<!-- Text-based flow showing the key interaction path, no images needed -->
```
[Screen A] ──action──► [Screen B] ──action──► [Outcome]
               │
           context/data
```

### Key Interactions
<!-- Fat marker level — major UI moments, not detailed specs -->
1. ...
2. ...

## Rabbit Holes (Risks)

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| ... | high/med/low | ... |

## Document Map

| Document | Type | Status |
|----------|------|--------|
| [[assess-report]] | Assess Report | ⬜ draft |
| [[domain-model]] | DDD Model | ⬜ draft |
| [[ux-behavior]] | UX Spec | ⬜ draft |
| [[usecases/_index]] | Use Cases | ⬜ draft |
| [[integration]] | Integration Map | ⬜ draft |
| [[scope-summary]] | Scope Summary | ⬜ draft |
| [[synthesis]] | Health Dashboard + Traceability + Risk + Dependency | ⬜ draft |
| [[feedback]] | Post-Sprint Feedback | ⬜ pending |

---

## Audit Report

*Generated from spec-lint.mjs output — do not edit manually.*
*skill_version: 2.1 | audit_rules_version: 2.1*

### Score Summary

| Layer | Weight | Raw Score | Weighted |
|-------|--------|-----------|---------|
| L0 Input Quality | 10% | —/100 | — |
| L1 Generation Complete | 20% | —/100 | — |
| L2 Document Quality | 30% | —/100 | — |
| L3 Execution Readiness | 40% | —/100 | — |
| **TOTAL** | | | **—/100** |

### Execution Gate
⬜ *Pending audit*

### Issues Found
⬜ *Pending audit*
